-keepclassmembers class com.healthkasafar.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
